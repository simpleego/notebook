package com.newlecture.web;

import java.io.IOException;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


@WebServlet("/calc2")
public class Calc2 extends HttpServlet {

	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		ServletContext application = request.getServletContext();
		HttpSession session = request.getSession();
		Cookie[] cookies = request.getCookies();
		
		response.setCharacterEncoding("UTF-8");
		response.setContentType("text/html; charset=UTF-8");
		
		String v_ = request.getParameter("v");
		String op = request.getParameter("operator");
		
		int v = 0;
			
		if(!v_.equals("")) {
			v = Integer.parseInt(v_);
		}
		
		//계산하기
		if(op.equals("=")) {
			
//			int x = (Integer)application.getAttribute("value");
//			int x = (Integer)session.getAttribute("value");
			int x = 0;
			// 쿠키는 여러개의 쿠키가 있을 수 있기때문에 for문을 통해서 찾아야 함.
			for(Cookie c : cookies) {
				if(c.getName().equals("value")) {
					x = Integer.parseInt(c.getValue());
					break;
				}
			}
			
			int y = v;
//			String operator = (String)application.getAttribute("op");
//			String operator = (String)session.getAttribute("op");
			String operator = "";
			for(Cookie c : cookies) {
				if(c.getName().equals("op")) {
					operator =c.getValue();
					break;
				}
			}
			
			
			int result = 0;		
			if(operator.equals("+")) {
				result = x + y;
			}else{
				result = x - y;
			}
			response.getWriter().printf("result is %d%n", result);
			
		}else { // 덧셈, 뺄셈 기호를 받으면 저장
//			application.setAttribute("value", v);
//			application.setAttribute("op", op);

//			session.setAttribute("value", v);
//			session.setAttribute("op", op);
			
			//쿠키값은 문자형으로만 보낼 수 있음. (url에서 사용할 수 있는 형태로만.)
			Cookie valueCookie = new Cookie("value", String.valueOf(v));
			Cookie opCookie = new Cookie("op", op);
			valueCookie.setPath("/Calc2");
			opCookie.setPath("/Calc2");
			// 클라이언트로 쿠키 보내기
			response.addCookie(valueCookie);
			response.addCookie(opCookie);
			response.sendRedirect("calc2.html");
			
		}
		
		
		
		
		
		
		
		
		
	}

}
